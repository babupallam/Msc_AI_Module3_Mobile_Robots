import sim
import time

def task1_lab3():
    client_id = sim.simxStart('127.0.0.1', 19999, True, True, 5000, 5)
    if client_id == -1:
        print("Failed to connect to CoppeliaSim")
        return

    _, left_motor_handle = sim.simxGetObjectHandle(client_id, 'Pioneer_p3dx_leftMotor', sim.simx_opmode_blocking)
    _, right_motor_handle = sim.simxGetObjectHandle(client_id, 'Pioneer_p3dx_rightMotor', sim.simx_opmode_blocking)

    _, proximity_sensor_handle = sim.simxGetObjectHandle(client_id, 'Pioneer_p3dx_ultrasonicSensor5', sim.simx_opmode_blocking)

    sim.simxReadProximitySensor(client_id, proximity_sensor_handle, sim.simx_opmode_streaming)
    time.sleep(0.5)

    def move_forward(distance):
        t = distance / 1  # Time to travel the distance
        sim.simxSetJointTargetVelocity(client_id, left_motor_handle, 1, sim.simx_opmode_streaming)
        sim.simxSetJointTargetVelocity(client_id, right_motor_handle, 1, sim.simx_opmode_streaming)
        time.sleep(t)
        sim.simxSetJointTargetVelocity(client_id, left_motor_handle, 0, sim.simx_opmode_streaming)
        sim.simxSetJointTargetVelocity(client_id, right_motor_handle, 0, sim.simx_opmode_streaming)

    def move_backward(distance):
        t = distance / 1
        sim.simxSetJointTargetVelocity(client_id, left_motor_handle, -1, sim.simx_opmode_streaming)
        sim.simxSetJointTargetVelocity(client_id, right_motor_handle, -1, sim.simx_opmode_streaming)
        time.sleep(t)
        sim.simxSetJointTargetVelocity(client_id, left_motor_handle, 0, sim.simx_opmode_streaming)
        sim.simxSetJointTargetVelocity(client_id, right_motor_handle, 0, sim.simx_opmode_streaming)

    def turn(angle):
        #time calculation for 180 degrees
        if angle == 90:
            timer =2
        else:
            timer =4
        sim.simxSetJointTargetVelocity(client_id, left_motor_handle, -1, sim.simx_opmode_streaming)
        sim.simxSetJointTargetVelocity(client_id, right_motor_handle, 1, sim.simx_opmode_streaming)
        time.sleep(timer)
        sim.simxSetJointTargetVelocity(client_id, left_motor_handle, 0, sim.simx_opmode_streaming)
        sim.simxSetJointTargetVelocity(client_id, right_motor_handle, 0, sim.simx_opmode_streaming)

    for _ in range(3):
        move_forward(2)
        turn(90)
        move_forward(6)
        turn(180)
        move_backward(6)
        turn(-90)

    sim.simxFinish(client_id)
task1_lab3()
